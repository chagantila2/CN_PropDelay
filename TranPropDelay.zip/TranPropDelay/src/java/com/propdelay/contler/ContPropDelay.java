/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.propdelay.contler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.json.JSONObject;


public class ContPropDelay extends HttpServlet {

  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            float totalLength = Float.parseFloat(request.getParameter("totalLength"));
            float totalRate = Float.parseFloat(request.getParameter("totalRate"));
            float totalSize = Float.parseFloat(request.getParameter("totalSize"));

            long speed = 280000000;

            float t = 450 * (speed * totalSize / totalLength / 800000) * (512000 / totalRate);
            float t2=(speed * totalSize) / totalLength;
            //console.log("value of t " + t);
            BigDecimal n = new BigDecimal(Math.ceil((t + 450) / (82 * (10000 / totalLength)) * .01 * 100) / 100);
            try {
                JSONObject objTransfer = new JSONObject();
                objTransfer.put("delay", n);
                objTransfer.put("propDelay", t);
                out.print(objTransfer);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
